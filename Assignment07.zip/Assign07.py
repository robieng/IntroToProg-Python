#-------------------------------------------------#
# Title: To Do List
# Dev:   RNg
# Date:  Nov 19th, 2018
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   RNg, 11/19/18, Added code to complete assignment 5
#   RNg, 12/1/18, Added Exception handling and used Pickling to load and unload data
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection
# TaskInput = values for the key 'Task' in dicRow
# PriorityInput = values for the key 'Priority' in dicRow
# Eliminate = user input to remove a key/value pair in dicRow

#-- Processing --#
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

dicRow={}
lstTable=[]

objFile = open("C:\_PythonClass\Assignment07\Todo.txt", "r")

try:
    for strData in objFile:
        TaskInput, PriorityInput = strData.split(',')
        dicRow={'Task':TaskInput.strip(), 'Priority':PriorityInput.strip()}
        lstTable.append(dicRow)
except ValueError:
        print("Please delete any empty spacelines in your file and try again...")

objFile.close()
print(lstTable)
