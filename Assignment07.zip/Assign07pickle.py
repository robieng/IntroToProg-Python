#-------------------------------------------------#
# Title: Simple Pickling
# Dev:   RNg
# Date: Dec 3rd, 2018
# ChangeLog: (Who, When, What)
#   RNg, 12/03/2018, Created the code
#-------------------------------------------------#

import pickle

# -- data --
tuplelist = [(1,'a'),(2,'b'),(3,'c')]

# -- pickle the data --

objFile = open("C:\_PythonClass\Assignment07\data.dat", "ab")
pickle.dump(tuplelist, objFile)
objFile.close()

# -- unpickle the data --

objFile = open("C:\_PythonClass\Assignment07\data.dat", "rb")
objFileData = pickle.load(objFile) #Note that load() only load one row of data.
objFile.close()

print(objFileData)
