#-------------------------------------------------#
# Title: To Do List
# Dev:   RNg
# Date:  Nov 19th, 2018
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   RNg, 11/19/18, Added code to complete assignment 5
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection
# TaskInput = values for the key 'Task' in dicRow
# PriorityInput = values for the key 'Priority' in dicRow
# Eliminate = user input to remove a key/value pair in dicRow

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

# Step 1 - Load data from a file
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"

dicRow={}
lstTable=[]

objFile = open("C:\_PythonClass\Assignment05\Todo.txt", "r")

for strData in objFile:
    TaskInput, PriorityInput = strData.split(',')
    dicRow={'Task':TaskInput, 'Priority':PriorityInput}
    lstTable.append(dicRow)
objFile.close()

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print(lstTable)
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        TaskInput = input('Enter the name of the task: ')
        PriorityInput = input('Enter the priority of the task:  ')
        dicRow = {'Task':TaskInput, 'Priority':PriorityInput}
        lstTable.append(dicRow)
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        Eliminate = input('Enter the name of the task you would like to remove: ')
        for row in lstTable:
            # print(row)
            if Eliminate in str(row): # this loop covers row into strings and see if the user input is in the string
                lstTable.remove(row)
        print(lstTable)
        # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        print(lstTable)
        input('enter to continue....')
        objFile = open("C:\_PythonClass\Assignment05\Todo.txt", "w")
        for dicRow in lstTable:
        #    print(dicRow.get('Task'),dicRow.get('Priority'))
        #    print(dicRow['Task'],dicRow['Priority'])
            objFile.write(str(dicRow['Task'])+','+ str(dicRow['Priority']) + '\n')
        print("Data saved to a file")
        objFile.close()
    elif (strChoice == '5'):
        break #and Exit the program

